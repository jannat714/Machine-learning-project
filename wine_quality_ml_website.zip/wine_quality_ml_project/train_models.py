from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, mean_absolute_error, mean_squared_error, r2_score
)
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge, Lasso
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.svm import SVC, SVR
from sklearn.naive_bayes import GaussianNB

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "winequality-red.csv"
ARTIFACT_DIR = BASE_DIR / "artifacts"
ARTIFACT_DIR.mkdir(exist_ok=True)

FEATURES = [
    "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
    "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
    "pH", "sulphates", "alcohol"
]
TARGET = "quality"

def make_classification_models():
    return {
        "Logistic Regression": Pipeline([("scaler", StandardScaler()), ("model", LogisticRegression(max_iter=3000, class_weight="balanced"))]),
        "K-Nearest Neighbors": Pipeline([("scaler", StandardScaler()), ("model", KNeighborsClassifier(n_neighbors=7))]),
        "Decision Tree": DecisionTreeClassifier(random_state=42, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=300, random_state=42, class_weight="balanced", n_jobs=-1),
        "Support Vector Machine": Pipeline([("scaler", StandardScaler()), ("model", SVC())]),
        "Naive Bayes": GaussianNB(),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42)
    }

def make_regression_models():
    return {
        "Linear Regression": Pipeline([("scaler", StandardScaler()), ("model", LinearRegression())]),
        "Ridge Regression": Pipeline([("scaler", StandardScaler()), ("model", Ridge(alpha=1.0))]),
        "Lasso Regression": Pipeline([("scaler", StandardScaler()), ("model", Lasso(alpha=0.001, max_iter=10000))]),
        "K-Nearest Neighbors": Pipeline([("scaler", StandardScaler()), ("model", KNeighborsRegressor(n_neighbors=7))]),
        "Decision Tree": DecisionTreeRegressor(random_state=42),
        "Random Forest": RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1),
        "Support Vector Regression": Pipeline([("scaler", StandardScaler()), ("model", SVR())]),
        "Gradient Boosting": GradientBoostingRegressor(random_state=42)
    }

def train_all():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH, sep=None, engine="python")
    missing = [c for c in FEATURES + [TARGET] if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing columns: {missing}")
    df = df[FEATURES + [TARGET]].dropna()
    X, y = df[FEATURES], df[TARGET].astype(int)

    # Stratified split keeps the six quality classes represented in both sets.
    Xc_train, Xc_test, yc_train, yc_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    classification_models = make_classification_models()
    classification_metrics = {}
    trained_classifiers = {}
    for name, model in classification_models.items():
        model.fit(Xc_train, yc_train)
        pred = model.predict(Xc_test)
        classification_metrics[name] = {
            "accuracy": float(accuracy_score(yc_test, pred)),
            "precision_macro": float(precision_score(yc_test, pred, average="macro", zero_division=0)),
            "recall_macro": float(recall_score(yc_test, pred, average="macro", zero_division=0)),
            "f1_macro": float(f1_score(yc_test, pred, average="macro", zero_division=0)),
            "confusion_matrix": confusion_matrix(yc_test, pred, labels=sorted(y.unique())).tolist(),
            "class_labels": [int(v) for v in sorted(y.unique())]
        }
        trained_classifiers[name] = model

    # Regression predicts the original numeric quality score.
    Xr_train, Xr_test, yr_train, yr_test = train_test_split(
        X, y.astype(float), test_size=0.20, random_state=42
    )
    regression_models = make_regression_models()
    regression_metrics = {}
    trained_regressors = {}
    for name, model in regression_models.items():
        model.fit(Xr_train, yr_train)
        pred = model.predict(Xr_test)
        mse = mean_squared_error(yr_test, pred)
        regression_metrics[name] = {
            "mae": float(mean_absolute_error(yr_test, pred)),
            "mse": float(mse),
            "rmse": float(mse ** 0.5),
            "r2": float(r2_score(yr_test, pred))
        }
        trained_regressors[name] = model

    best_classifier = max(classification_metrics, key=lambda n: classification_metrics[n]["f1_macro"])
    best_regressor = max(regression_metrics, key=lambda n: regression_metrics[n]["r2"])

    joblib.dump({
        "classification": trained_classifiers,
        "regression": trained_regressors,
        "features": FEATURES,
        "target": TARGET
    }, ARTIFACT_DIR / "models.joblib")

    metrics = {
        "dataset": {
            "rows": int(len(df)),
            "columns": int(len(df.columns)),
            "features": FEATURES,
            "target": TARGET,
            "quality_classes": [int(v) for v in sorted(y.unique())],
            "class_distribution": {str(int(k)): int(v) for k, v in y.value_counts().sort_index().items()},
            "missing_values": int(df.isna().sum().sum())
        },
        "classification": classification_metrics,
        "regression": regression_metrics,
        "best": {"classification": best_classifier, "regression": best_regressor}
    }
    with open(ARTIFACT_DIR / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    print("Training complete.")
    print("Best classification model:", best_classifier)
    print("Best regression model:", best_regressor)
    return metrics

if __name__ == "__main__":
    train_all()
