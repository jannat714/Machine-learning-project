from pathlib import Path
import json
import subprocess
import sys
import joblib
import pandas as pd
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
ARTIFACT_DIR = BASE_DIR / "artifacts"
DATA_PATH = BASE_DIR / "data" / "winequality-red.csv"
FEATURES = [
    "fixed acidity", "volatile acidity", "citric acid", "residual sugar",
    "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density",
    "pH", "sulphates", "alcohol"
]

app = FastAPI(title="Wine Quality ML Dashboard", description="Multiclass classification and regression for red wine quality.")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

def ensure_trained():
    model_file = ARTIFACT_DIR / "models.joblib"
    metrics_file = ARTIFACT_DIR / "metrics.json"
    if not model_file.exists() or not metrics_file.exists():
        result = subprocess.run([sys.executable, str(BASE_DIR / "train_models.py")], cwd=str(BASE_DIR), capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError("Model training failed: " + result.stderr[-2000:])
    models = joblib.load(model_file)
    metrics = json.loads(metrics_file.read_text(encoding="utf-8"))
    return models, metrics

MODELS, METRICS = ensure_trained()

class WineInput(BaseModel):
    fixed_acidity: float = Field(..., alias="fixed acidity", ge=0, le=30)
    volatile_acidity: float = Field(..., alias="volatile acidity", ge=0, le=3)
    citric_acid: float = Field(..., alias="citric acid", ge=0, le=2)
    residual_sugar: float = Field(..., alias="residual sugar", ge=0, le=100)
    chlorides: float = Field(..., ge=0, le=1)
    free_sulfur_dioxide: float = Field(..., alias="free sulfur dioxide", ge=0, le=300)
    total_sulfur_dioxide: float = Field(..., alias="total sulfur dioxide", ge=0, le=500)
    density: float = Field(..., ge=0.9, le=1.1)
    pH: float = Field(..., ge=0, le=14)
    sulphates: float = Field(..., ge=0, le=5)
    alcohol: float = Field(..., ge=0, le=30)

    def as_frame(self):
        values = {
            "fixed acidity": self.fixed_acidity,
            "volatile acidity": self.volatile_acidity,
            "citric acid": self.citric_acid,
            "residual sugar": self.residual_sugar,
            "chlorides": self.chlorides,
            "free sulfur dioxide": self.free_sulfur_dioxide,
            "total sulfur dioxide": self.total_sulfur_dioxide,
            "density": self.density,
            "pH": self.pH,
            "sulphates": self.sulphates,
            "alcohol": self.alcohol
        }
        return pd.DataFrame([[values[c] for c in FEATURES]], columns=FEATURES)

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "features": FEATURES,
        "classification_models": list(MODELS["classification"].keys()),
        "regression_models": list(MODELS["regression"].keys())
    })

@app.get("/api/metrics")
def get_metrics():
    return METRICS

@app.get("/api/dataset")
def dataset_overview():
    df = pd.read_csv(DATA_PATH, sep=None, engine="python")
    return {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "features": FEATURES,
        "target": "quality",
        "quality_distribution": {str(int(k)): int(v) for k, v in df["quality"].value_counts().sort_index().items()},
        "sample": df.head(8).to_dict(orient="records")
    }

@app.post("/api/predict/classification")
def predict_classification(payload: WineInput, model: str = "Random Forest"):
    if model not in MODELS["classification"]:
        raise HTTPException(status_code=400, detail="Unknown classification model.")
    prediction = int(MODELS["classification"][model].predict(payload.as_frame())[0])
    return {"model": model, "predicted_quality_class": prediction, "interpretation": f"Predicted wine quality class: {prediction}"}

@app.post("/api/predict/regression")
def predict_regression(payload: WineInput, model: str = "Random Forest"):
    if model not in MODELS["regression"]:
        raise HTTPException(status_code=400, detail="Unknown regression model.")
    prediction = float(MODELS["regression"][model].predict(payload.as_frame())[0])
    return {"model": model, "predicted_quality_score": round(prediction, 3), "interpretation": "Predicted numerical quality score (may be decimal because this is regression)."}

@app.get("/health")
def health():
    return {"status": "ok", "models_loaded": True}
