const featureDefs=[
 ["fixed acidity","Fixed acidity",7.4],["volatile acidity","Volatile acidity",0.70],["citric acid","Citric acid",0.00],
 ["residual sugar","Residual sugar",1.9],["chlorides","Chlorides",0.076],["free sulfur dioxide","Free sulfur dioxide",11],
 ["total sulfur dioxide","Total sulfur dioxide",34],["density","Density",0.9978],["pH","pH",3.51],
 ["sulphates","Sulphates",0.56],["alcohol","Alcohol",9.4]
];
let metricsData=null,datasetData=null;
const $=id=>document.getElementById(id);
const fmt=v=>Number(v).toFixed(3);

function navigate(viewId){
 document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===viewId));
 window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-go]").forEach(el=>el.addEventListener("click",e=>{
 e.preventDefault();navigate(el.dataset.go);
}));

function buildInputs(containerId){
 $(containerId).innerHTML=featureDefs.map(([key,label,value])=>
  `<label class="field">${label}<input type="number" step="any" required name="${key}" value="${value}"></label>`
 ).join("");
}
function fillModelSelect(selectId,modelNames,best){
 $(selectId).innerHTML=modelNames.map(n=>`<option value="${n}">${n}${n===best?" (Best)":""}</option>`).join("");
 $(selectId).value=best;
}
function fillMetricsTable(id,models,fields,best){
 $(id).innerHTML=Object.entries(models).map(([name,values])=>
  `<tr><td>${name}${name===best?" ★":""}</td>${fields.map(f=>`<td>${fmt(values[f])}</td>`).join("")}</tr>`
 ).join("");
}
function renderConfusion(name){
 const item=metricsData.classification[name],labels=item.class_labels,matrix=item.confusion_matrix;
 const max=Math.max(...matrix.flat(),1);
 $("confusionMatrix").innerHTML=matrix.map((row,i)=>
  `<div class="matrix-row">${row.map((v,j)=>{
   const alpha=.06+.68*(v/max);
   return `<div class="matrix-cell" title="Actual ${labels[i]}, predicted ${labels[j]}" style="background:rgba(49,94,145,${alpha});color:${alpha>.38?"white":"#23372e"}">${v}</div>`;
  }).join("")}</div>`
 ).join("");
}
function drawCharts(){
 const dist=datasetData.quality_distribution;
 new Chart($("distributionChart"),{type:"bar",data:{labels:Object.keys(dist),datasets:[{label:"Samples",data:Object.values(dist),backgroundColor:"#739aab",borderRadius:7}]},options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:"#edf0ed"}},x:{grid:{display:false}}}}});
 new Chart($("classificationChart"),{type:"bar",data:{labels:Object.keys(metricsData.classification),datasets:[{label:"Accuracy",data:Object.values(metricsData.classification).map(x=>x.accuracy),backgroundColor:"#739aab",borderRadius:6}]},options:{indexAxis:"y",plugins:{legend:{display:false}},scales:{x:{min:0,max:1,grid:{color:"#edf0ed"}},y:{grid:{display:false}}}}});
 new Chart($("regressionChart"),{type:"bar",data:{labels:Object.keys(metricsData.regression),datasets:[{label:"R²",data:Object.values(metricsData.regression).map(x=>x.r2),backgroundColor:"#6d9b7e",borderRadius:6}]},options:{indexAxis:"y",plugins:{legend:{display:false}},scales:{x:{grid:{color:"#edf0ed"}},y:{grid:{display:false}}}}});
}
async function loadDashboard(){
 const [mr,dr]=await Promise.all([fetch("/api/metrics"),fetch("/api/dataset")]);
 if(!mr.ok||!dr.ok)throw new Error("Could not load project metrics or dataset.");
 metricsData=await mr.json();datasetData=await dr.json();

 $("rows").textContent=datasetData.rows.toLocaleString();
 $("overviewRows").textContent=datasetData.rows.toLocaleString();
 $("overviewCols").textContent=datasetData.columns;
 $("missing").textContent=metricsData.dataset.missing_values;
 $("featureList").innerHTML=featureDefs.map(x=>`<span>${x[1]}</span>`).join("");

 const bestC=metricsData.best.classification,bestR=metricsData.best.regression;
 $("bestClassifier").textContent=bestC;$("bestRegressor").textContent=bestR;
 fillMetricsTable("classificationTable",metricsData.classification,
  ["accuracy","precision_macro","recall_macro","f1_macro"],bestC);
 fillMetricsTable("regressionTable",metricsData.regression,["mae","mse","rmse","r2"],bestR);
 fillModelSelect("classificationModel",Object.keys(metricsData.classification),bestC);
 fillModelSelect("regressionModel",Object.keys(metricsData.regression),bestR);
 $("confusionModel").innerHTML=Object.keys(metricsData.classification).map(n=>`<option>${n}</option>`).join("");
 $("confusionModel").value=bestC;
 $("confusionModel").addEventListener("change",e=>renderConfusion(e.target.value));
 renderConfusion(bestC);drawCharts();
}
async function submitPrediction(event,task){
 event.preventDefault();
 const prefix=task==="classification"?"classification":"regression";
 const form=$(prefix+"Form"),model=$(prefix+"Model"),result=$(prefix+"Result");
 const payload={};
 featureDefs.forEach(([key])=>{
  const input=form.querySelector(`input[name="${key}"]`);
  payload[key]=Number(input.value);
 });
 const endpoint=task==="classification"?"/api/predict/classification":"/api/predict/regression";
 const resultClass=task==="classification";
 result.querySelector("h3").textContent="Calculating prediction…";
 result.querySelector("p").textContent="The selected trained model is processing the measurements.";
 result.querySelector(".result-value").textContent="…";
 try{
  const response=await fetch(`${endpoint}?model=${encodeURIComponent(model.value)}`,{
   method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)
  });
  const data=await response.json();
  if(!response.ok)throw new Error(data.detail||"Prediction request failed.");
  result.querySelector("h3").textContent=resultClass?"Predicted quality category":"Predicted numerical score";
  result.querySelector("p").textContent=`Selected model: ${data.model}`;
  result.querySelector(".result-value").textContent=resultClass?data.predicted_quality_class:Number(data.predicted_quality_score).toFixed(2);
  result.querySelector(".result-foot").textContent=data.interpretation;
 }catch(error){
  result.querySelector("h3").textContent="Prediction could not be completed";
  result.querySelector("p").textContent=error.message;
  result.querySelector(".result-value").textContent="—";
 }
}
$("classificationForm").addEventListener("submit",e=>submitPrediction(e,"classification"));
$("regressionForm").addEventListener("submit",e=>submitPrediction(e,"regression"));
document.querySelectorAll("[data-reset]").forEach(btn=>btn.addEventListener("click",()=>{
 const id=btn.dataset.reset;
 buildInputs(id);
}));
buildInputs("classificationInputs");
buildInputs("regressionInputs");
loadDashboard().catch(error=>{
 console.error(error);
 document.querySelector(".status").innerHTML="<i></i> Dashboard loading issue";
 alert("Dashboard data could not be loaded. Please check that the FastAPI server is running.");
});
