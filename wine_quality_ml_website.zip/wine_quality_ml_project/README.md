# Wine Quality Machine Learning Project

A complete FastAPI website using the supplied `winequality-red.csv` dataset. The landing page presents two clearly separated choices: **Classification** and **Regression**. Each opens its own dedicated section with its own model comparison, metrics, charts, model selector, input form and prediction result.

## Models included

**Multiclass classification:** Logistic Regression, K-Nearest Neighbors, Decision Tree, Random Forest, Support Vector Machine, Naive Bayes, Gradient Boosting.

**Regression:** Linear Regression, Ridge, Lasso, K-Nearest Neighbors, Decision Tree, Random Forest, Support Vector Regression, Gradient Boosting.

## Project structure

```text
wine_quality_ml_project/
├── main.py
├── train_models.py
├── requirements.txt
├── README.md
├── data/
│   └── winequality-red.csv
├── artifacts/             # generated after training
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

## Run locally

Python 3.10+ is recommended.

1. Extract the ZIP file and open a terminal in the project folder.
2. Create and activate a virtual environment (recommended).
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Train all models:

   ```bash
   python train_models.py
   ```

   This creates `artifacts/models.joblib` and `artifacts/metrics.json`.

5. Start the website:

   ```bash
   uvicorn main:app --reload
   ```

6. Open this address in your browser:

   `http://127.0.0.1:8000`

The app also trains models automatically on first startup if the artifacts do not exist.

## API endpoints

- `GET /api/dataset` — dataset overview and sample rows
- `GET /api/metrics` — all model evaluation metrics
- `POST /api/predict/classification?model=Random%20Forest` — multiclass prediction
- `POST /api/predict/regression?model=Random%20Forest` — numeric regression prediction
- `GET /health` — health check

Prediction JSON must contain all 11 feature names exactly as in the CSV, including spaces, e.g.:

```json
{
  "fixed acidity": 7.4,
  "volatile acidity": 0.7,
  "citric acid": 0.0,
  "residual sugar": 1.9,
  "chlorides": 0.076,
  "free sulfur dioxide": 11,
  "total sulfur dioxide": 34,
  "density": 0.9978,
  "pH": 3.51,
  "sulphates": 0.56,
  "alcohol": 9.4
}
```

## Methodology and notes

- Classification uses the original observed quality labels (3, 4, 5, 6, 7, 8), not artificially merged classes.
- Classification uses a stratified 80/20 train/test split.
- Regression uses an 80/20 train/test split and predicts the original numeric quality.
- Scaling is applied through pipelines to scale-sensitive algorithms.
- Macro-averaged precision, recall, and F1 are included so minority classes are not ignored.
- Regression reports MAE, MSE, RMSE, and R².
- The best classification model is selected by macro F1; the best regression model by R².
- The held-out test metrics are for educational comparison, not a guarantee of performance on new wine samples.
- Chart.js is loaded from a CDN, so the charts require an internet connection in the browser. The core API and prediction routes run locally.
